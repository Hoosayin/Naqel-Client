export const TabMenu = {
    padding: "10px",
    backgroundColor: "#3A3A3C",
    width: "100%",
    margin: "0px",
};

export default {
    TabMenu,
};