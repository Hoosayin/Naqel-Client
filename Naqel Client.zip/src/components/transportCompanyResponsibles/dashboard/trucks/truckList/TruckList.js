import React, { Component } from "react";
import TrucksList from "./TrucksList";

class TruckList extends Component {
    render() {
        return <section>
            <TrucksList />
        </section>;
    }
};

export default TruckList;