import React, { Component } from "react";
import TruckJobsBrowser from "./TruckJobsBrowser";

class TruckJobs extends Component {
    render() {
        return <section>
            <TruckJobsBrowser />
        </section>;
    }
};

export default TruckJobs;