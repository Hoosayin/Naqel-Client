import React, { Component } from "react";
import TruckAccountStatementBrowser from "./TruckAccountStatementBrowser";

class TrucksAccountStatements extends Component {
    render() {
        return <section>
            <TruckAccountStatementBrowser />
        </section>;
    }
};

export default TrucksAccountStatements;