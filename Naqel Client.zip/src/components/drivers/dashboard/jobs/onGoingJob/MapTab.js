import React, { Component } from "react";
import Map from "../../../../../controls/Map";

class MapTab extends Component {
    render() {
        return <section>
            <div>
                <Map />
            </div>
        </section>;
    }
};

export default MapTab;