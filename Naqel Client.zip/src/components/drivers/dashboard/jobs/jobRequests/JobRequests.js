import React, { Component } from "react";
import JobRequestsList from "./JobRequestsList.js";

class JobRequests extends Component {
    render() {
        return <section>
            <JobRequestsList />
        </section>;
    }
};

export default JobRequests;