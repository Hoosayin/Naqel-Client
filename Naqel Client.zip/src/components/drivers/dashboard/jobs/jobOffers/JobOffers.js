import React, { Component } from "react";
import JobOfferPostsList from "./JobOfferPostsList";

class JobOffers extends Component {
   render() {
       return <section>
           <JobOfferPostsList />
       </section>;
    }
};

export default JobOffers;