import React, { Component } from "react";
import QuestionsList from "./QuestionsList";

class Questions extends Component {
    render() {
        return <section>
            <QuestionsList />
        </section>;
    }
};

export default Questions;