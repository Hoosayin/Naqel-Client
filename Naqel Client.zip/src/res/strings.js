module.exports = {
    APP_NAME: "Naqel",
    USER_TOKEN: "userToken",
    USER_NOT_FOUND: "Username not found.",
    INVALID_PASSWORD: "Invalid password.",
    USERNAME_OR_EMAIL_TAKEN: "Username or email is already taken.",
    NAQEL_SERVER: "http://localhost:1337/",
    IMAGE_UPLOADER: "https://us-central1-naqel-transport-jobs.cloudfunctions.net/uploadImage"
};